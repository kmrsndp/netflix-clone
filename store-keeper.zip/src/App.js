import './App.css';
import AddItem from './components/AddItem';
import TableEntry from './components/TableEntry';

function App() {
  return (
    <div>
      <AddItem></AddItem>
      <TableEntry></TableEntry>

    </div>
      
    
  );
}

export default App;
