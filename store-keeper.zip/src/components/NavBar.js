import React from 'react'

const NavBar = () => {
  return (
    <div 
    className='flex bg-slate-600 w-full items-center justify-center text-gray-200 
    h-12 py-3 text-xl '>
        Lakhshmi Narayan Enterprises</div>
  )
}

export default NavBar